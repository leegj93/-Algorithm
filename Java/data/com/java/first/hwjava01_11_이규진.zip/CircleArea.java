package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		int a = 5;
		float b = (float)(a*a*3.14);
		System.out.println("반지름이 "+a + "cm인 원의 넓이는 "+ b+"Cm2입니다");

	}

}
