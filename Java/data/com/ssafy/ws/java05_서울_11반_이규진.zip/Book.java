package com.ssafy.ws;

public class Book {
	private String isbn;
	private String title;
	private String author;
	private String publisher;
//	private int year;
//	private int month;
	private int price;
	private String desc;
	public Book(String in, String tl, String ath, String pb, int p, String dc){
		isbn=in; title = tl; author = ath; publisher =pb; price=p; desc = dc;
	}
	
	public String toString() {
		String str= isbn +"	|"+
							title +"	|"+
							author +"	|"+
							publisher +"	|"+
							price +"	|"+
							desc;
		return str;
	}
}
