package com.ssafy.ws;

public class Magazine {
	private String isbn;
	private String title;
	private String author;
	private String publisher;
	private int year;
	private int month;
	private int price;
	private String desc;
	public Magazine(){
		
	}
	public Magazine(String in, String tl, String ath, String pb, int y, int m, int p, String dc){
		isbn=in; title = tl; author = ath; publisher =pb; year= y; month = m; price=p; desc = dc;
	}
	public String toString() {
		String str= isbn +"	|"+
							title +"	|"+
							author +"	|"+
							publisher +"	|"+
							price +"	|"+
							desc +"	|"+
							year +"."+
							month;
		return str;
	}

}
