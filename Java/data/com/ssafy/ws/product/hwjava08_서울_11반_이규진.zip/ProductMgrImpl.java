package com.ssafy.ws.product;

import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {
	ArrayList<Product> prr = new ArrayList<Product>();

	@Override
	public void add(Product p) {
		prr.add(p);
	}

	@Override
	public ArrayList<Product> findAll() {
		int i = 0;
		for (i = 0; i < prr.size(); i++) {
			prr.get(i).print();
		}
		return prr;
	}

	@Override
	public ArrayList<Product> findIsbn(String isbn) {
		int i = 0;
		System.out.println("======================");
		for (i = 0; i < prr.size(); i++) {
			if (prr.get(i).getIsbn().contains(isbn)) {
				prr.get(i).print();

			}
		}
		return prr;
	}

	@Override
	public ArrayList<Product> findTitle(String title) {
		int i = 0;
		System.out.println("해당 제품명으로 검색..");
		System.out.println("======================");
		for (i = 0; i < prr.size(); i++) {
			if (prr.get(i).getTitle().contains(title)) {
				prr.get(i).print();

			}
		}
		return prr;
	}

	@Override
	public ArrayList<Product> findTv() {
		System.out.println("TV만 검색");
		for (Product p : prr) {
			if (p instanceof Tv) {
				p.print();
			}
		}
		return prr;
	}

	@Override
	public ArrayList<Product> findRF() {
		System.out.println("냉장고만 검색");
		for (Product p : prr) {
			if (p instanceof Refrigerator) {
				p.print();
			}
		}
		return prr;
	}

	@Override
	public ArrayList<Product> updatePr(String isbn, int price) {
		System.out.println("해당 제품 정보 갱신");
		int i = 0;
		for (i = 0; i < prr.size(); i++) {
			if (prr.get(i).getIsbn().contains(isbn)) {
				prr.get(i).setPrice(price);

			}
		}
		return prr;
	}

	@Override
	public ArrayList<Product> removePr(String isbn) {
		System.out.println("해당 제품 삭제");
		int i;

		for (i = 0; i < prr.size(); i++) {
			if (prr.get(i).getIsbn().equals(isbn)) {
				prr.remove(i);
				break;

			}
		}
		return prr;

	}

	@Override
	public int totalPrice() {
		System.out.println("재고 금액의 총합");
		int sum = 0;
		for (int i = 0; i < prr.size(); i++) {
//			System.out.println(prr.get(i).getPrice());
			sum += prr.get(i).getPrice() * prr.get(i).getStock();
		}
		System.out.println(sum);
		return sum;
	}

	@Override
	public void findRFvol() {
		System.out.println("400L이상 냉장고");
		ArrayList<Refrigerator> temp = new ArrayList<>();
		for (Product product : prr) {
			if(product instanceof Refrigerator) {
				temp.add((Refrigerator) product);
			}
		}
		int i = 0;
		for (i = 0; i < temp.size(); i++) {
			if (Integer.parseInt(temp.get(i).getVolume()) >= 400) {
				temp.get(i).print();

			}
		}
//		return prr;
	}

	@Override
	public void findTvInch() {
		System.out.println("50inch이상 TV");
		ArrayList<Tv> temp = new ArrayList<>();
		for (Product product : prr) {
			if(product instanceof Tv) {
				temp.add((Tv) product);
			}
		}
		int i = 0;
		for (i = 0; i < temp.size(); i++) {

			if ((temp.get(i).getInch()) >= 50) {
				temp.get(i).print();

			}
		}
//		return prr;8
		
	}

}
